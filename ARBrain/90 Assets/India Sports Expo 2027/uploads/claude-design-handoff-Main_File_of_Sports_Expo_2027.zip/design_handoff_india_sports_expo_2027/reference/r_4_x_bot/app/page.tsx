import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/clZpIOGef0TGq99W/scene.splinecode" 
      />
    </main>
  );
}
