// India Sports Expo 2027 — shared DEMO data. All entities illustrative unless stated.
(function () {
  const Z = {
    A: { id: 'A', name: 'India Sports & Heritage', short: 'India', color: '#9E1B22', tint: '#F6E7E6', blurb: 'States, Ministry, federations and the story of Indian sport.' },
    B: { id: 'B', name: 'Sports Goods & Infrastructure', short: 'Manufacturing', color: '#3F4A56', tint: '#E8EBEE', blurb: 'Manufacturers, venue builders, surfaces, apparel and supply chain.' },
    C: { id: 'C', name: 'Sports Tech & Experience', short: 'Technology', color: '#0B6E4F', tint: '#E3F1EB', blurb: 'SportsTech, startups, sports science and live experiences.' },
    D: { id: 'D', name: 'Sports Business & Investment', short: 'Business', color: '#141416', tint: '#ECEBE8', blurb: 'Country pavilions, buyers, investors, deal rooms and lounges.' }
  };
  // Hall 2 schematic — 1000 x 500 units. Derived from Hall2_Layout_with_Legend (schematic, not to scale).
  const clusters = [
    { id: 'STA', zone: 'A', name: 'States & UTs Sports Destinations', meta: '4 pavilions', x: 20, y: 20, w: 200, h: 92, kind: 'pav', n: 4 },
    { id: 'THM', zone: 'A', name: 'Theme Pavilion', meta: 'Hero pavilion', x: 236, y: 20, w: 226, h: 92, kind: 'hero', n: 1 },
    { id: 'MYS', zone: 'A', name: 'Ministry of Youth Affairs & Sports', meta: '2 pavilions', x: 20, y: 128, w: 140, h: 84, kind: 'pav', n: 2 },
    { id: 'FED', zone: 'A', name: 'Federations & Institutions', meta: '2 pavilions', x: 172, y: 128, w: 140, h: 84, kind: 'pav', n: 2 },
    { id: 'HER', zone: 'A', name: 'India Sports Heritage & Interactive', meta: '2 pavilions', x: 324, y: 128, w: 138, h: 84, kind: 'pav', n: 2 },
    { id: 'SGM', zone: 'B', name: 'Sports Goods Manufacturing', meta: '31 stalls · 2 pavilions', x: 538, y: 20, w: 210, h: 92, kind: 'stalls', n: 31, cols: 11 },
    { id: 'SIV', zone: 'B', name: 'Sports Infrastructure & Venue Build', meta: '32 stalls · 1 pavilion', x: 762, y: 20, w: 218, h: 92, kind: 'stalls', n: 32, cols: 11 },
    { id: 'OEM', zone: 'B', name: 'OEM / ODM & Supply Chain', meta: '20 stalls', x: 538, y: 128, w: 124, h: 84, kind: 'stalls', n: 20, cols: 7 },
    { id: 'APF', zone: 'B', name: 'Apparel & Footwear', meta: '14 stalls · 1 pavilion', x: 674, y: 128, w: 110, h: 84, kind: 'stalls', n: 14, cols: 5 },
    { id: 'SRF', zone: 'B', name: 'Surfaces & Turf', meta: '9 stalls · 1 pavilion', x: 796, y: 128, w: 84, h: 84, kind: 'stalls', n: 9, cols: 3 },
    { id: 'LSE', zone: 'B', name: 'Lighting, Seating & Engineering', meta: '13 stalls', x: 892, y: 128, w: 88, h: 84, kind: 'stalls', n: 13, cols: 4 },
    { id: 'CTY', zone: 'D', name: 'International / Country Pavilions', meta: '6 pavilions', x: 20, y: 288, w: 210, h: 92, kind: 'pav', n: 6 },
    { id: 'ISX', zone: 'D', name: 'India Sports Business Exchange', meta: 'Matchmaking floor', x: 246, y: 288, w: 216, h: 92, kind: 'hero', n: 1 },
    { id: 'B2B', zone: 'D', name: 'B2B Meeting Zone & Networking Café', meta: '40 tables', x: 20, y: 396, w: 150, h: 84, kind: 'room', n: 1 },
    { id: 'HBL', zone: 'D', name: 'Hosted Buyer Lounge', meta: 'Invite only', x: 182, y: 396, w: 92, h: 84, kind: 'room', n: 1 },
    { id: 'MOU', zone: 'D', name: 'MoU / Deal Rooms', meta: '6 rooms', x: 286, y: 396, w: 64, h: 84, kind: 'room', n: 1 },
    { id: 'INV', zone: 'D', name: 'Investor Lounge', meta: 'Accredited', x: 362, y: 396, w: 50, h: 40, kind: 'room', n: 1 },
    { id: 'FDL', zone: 'D', name: 'Federation Lounge', meta: 'Accredited', x: 362, y: 440, w: 50, h: 40, kind: 'room', n: 1 },
    { id: 'CEO', zone: 'D', name: 'CEO Lounge', meta: 'Invite only', x: 422, y: 396, w: 40, h: 84, kind: 'room', n: 1 },
    { id: 'STI', zone: 'C', name: 'SportsTech & Innovation', meta: '34 stalls · 1 pavilion', x: 538, y: 288, w: 210, h: 92, kind: 'stalls', n: 34, cols: 12 },
    { id: 'IAS', zone: 'C', name: 'Innovation Arena Stage', meta: '324 seats', x: 762, y: 288, w: 218, h: 92, kind: 'stage', n: 1 },
    { id: 'SUV', zone: 'C', name: 'Startup Village', meta: '30 stalls · 1 pavilion', x: 538, y: 396, w: 150, h: 84, kind: 'stalls', n: 30, cols: 10 },
    { id: 'PSS', zone: 'C', name: 'Performance & Sports Science', meta: '30 stalls · 1 pavilion', x: 700, y: 396, w: 140, h: 84, kind: 'stalls', n: 30, cols: 10 },
    { id: 'IEX', zone: 'C', name: 'Interactive Experiences', meta: 'Demo floor', x: 852, y: 396, w: 58, h: 84, kind: 'room', n: 1 },
    { id: 'TSA', zone: 'C', name: 'Try Sport Arena', meta: 'Live experience', x: 920, y: 396, w: 60, h: 84, kind: 'room', n: 1 }
  ];
  const exhibitors = [
    { id: 'apex', name: 'Apex Sports India', city: 'Jalandhar, India', country: 'India', sector: 'Football Equipment', stall: 'B-SGM-017', zone: 'B', cluster: 'SGM', type: 'Manufacturer · Exporter', products: ['Match Footballs', 'Training Balls', 'Goal Systems', 'Training Accessories'], seeking: 'European Distributors', sport: 'Football', booth: 'Premium Booth' },
    { id: 'willow', name: 'Meerut Willow Works', city: 'Meerut, India', country: 'India', sector: 'Cricket Equipment', stall: 'B-SGM-009', zone: 'B', cluster: 'SGM', type: 'Manufacturer', products: ['English Willow Bats', 'Protective Pads', 'Leather Balls'], seeking: 'UK & Australia retail', sport: 'Cricket', booth: 'Standard Booth' },
    { id: 'arena', name: 'ArenaBuild Infrastructure', city: 'Pune, India', country: 'India', sector: 'Stadium Construction', stall: 'B-SIV-004', zone: 'B', cluster: 'SIV', type: 'EPC Contractor', products: ['Modular Stands', 'Roof Systems', 'Venue Fit-out'], seeking: 'State sports authorities', sport: 'Multi-sport', booth: 'Raw Space' },
    { id: 'turf', name: 'TurfLine Systems', city: 'Rotterdam, Netherlands', country: 'Netherlands', sector: 'Surfaces & Turf', stall: 'B-SRF-003', zone: 'B', cluster: 'SRF', type: 'Manufacturer', products: ['FIFA Quality Turf', 'Hockey Water-based Turf', 'Shock Pads'], seeking: 'Indian installation partners', sport: 'Hockey', booth: 'Premium Booth' },
    { id: 'lumen', name: 'Luminar Stadium Lighting', city: 'Stuttgart, Germany', country: 'Germany', sector: 'Lighting', stall: 'B-LSE-005', zone: 'B', cluster: 'LSE', type: 'Manufacturer', products: ['Broadcast LED Floodlights', 'Light Show Control'], seeking: 'Venue developers', sport: 'Multi-sport', booth: 'Premium Booth' },
    { id: 'stride', name: 'Stridewell Footwear', city: 'Agra, India', country: 'India', sector: 'Performance Footwear', stall: 'B-APF-008', zone: 'B', cluster: 'APF', type: 'OEM · Brand', products: ['Spike Plates', 'Running Midsoles', 'Court Shoes'], seeking: 'Global brand OEM contracts', sport: 'Athletics', booth: 'Standard Booth' },
    { id: 'origin', name: 'Origin Supply Co.', city: 'Tiruppur, India', country: 'India', sector: 'Teamwear OEM', stall: 'B-OEM-014', zone: 'B', cluster: 'OEM', type: 'OEM / ODM', products: ['Sublimated Teamwear', 'Recycled Polyester Kits'], seeking: 'Club & league licensees', sport: 'Football', booth: 'Standard Booth' },
    { id: 'motion', name: 'MotionIQ SportsTech', city: 'Bengaluru, India', country: 'India', sector: 'AI Coaching', stall: 'C-STI-011', zone: 'C', cluster: 'STI', type: 'SportsTech', products: ['Computer-vision Coaching', 'Skill Benchmarks'], seeking: 'Federations, academies', sport: 'Cricket', booth: 'Premium Booth' },
    { id: 'matrix', name: 'SportMatrix Analytics', city: 'Gurugram, India', country: 'India', sector: 'Performance Analytics', stall: 'C-STI-022', zone: 'C', cluster: 'STI', type: 'SportsTech', products: ['Match Data Platform', 'Scouting Index'], seeking: 'Leagues, broadcasters', sport: 'Football', booth: 'Standard Booth' },
    { id: 'velocity', name: 'Velocity Performance Labs', city: 'Hyderabad, India', country: 'India', sector: 'Sports Science', stall: 'C-PSS-006', zone: 'C', cluster: 'PSS', type: 'Lab · Services', products: ['Force Plates', 'Recovery Protocols', 'VO2 Testing'], seeking: 'High-performance centres', sport: 'Athletics', booth: 'Premium Booth' },
    { id: 'hayate', name: 'Hayate Sports Engineering', city: 'Osaka, Japan', country: 'Japan', sector: 'Timing Systems', stall: 'D-CTY-JP1', zone: 'D', cluster: 'CTY', type: 'Manufacturer', products: ['Photo-finish Timing', 'Start Systems'], seeking: 'Athletics federations', sport: 'Athletics', booth: 'Country Pavilion' },
    { id: 'flex', name: 'FlexSeat Arenas', city: 'Melbourne, Australia', country: 'Australia', sector: 'Seating', stall: 'B-LSE-011', zone: 'B', cluster: 'LSE', type: 'Manufacturer', products: ['Retractable Seating', 'Tip-up Stadium Seats'], seeking: 'Indian venue projects', sport: 'Multi-sport', booth: 'Standard Booth' }
  ];
  const products = [
    { name: 'Pro Match Football FQ-5', by: 'Apex Sports India', stall: 'B-SGM-017', cat: 'Football', type: 'Equipment', moq: 'MOQ 1,000', tag: 'FIFA Quality (sample claim)' },
    { name: 'Portable Aluminium Goal 7.32 m', by: 'Apex Sports India', stall: 'B-SGM-017', cat: 'Football', type: 'Equipment', moq: 'MOQ 20', tag: 'Export ready' },
    { name: 'Grade 1 English Willow Bat', by: 'Meerut Willow Works', stall: 'B-SGM-009', cat: 'Cricket', type: 'Equipment', moq: 'MOQ 200', tag: 'Hand-made' },
    { name: 'AquaPlay Hockey Turf', by: 'TurfLine Systems', stall: 'B-SRF-003', cat: 'Hockey', type: 'Surface', moq: 'Per pitch', tag: 'Water-based' },
    { name: 'LX-2000 Broadcast Floodlight', by: 'Luminar Stadium Lighting', stall: 'B-LSE-005', cat: 'Outdoor', type: 'Infrastructure', moq: 'Project', tag: '4K broadcast' },
    { name: 'Carbon Sprint Spike Plate', by: 'Stridewell Footwear', stall: 'B-APF-008', cat: 'Athletics', type: 'Footwear', moq: 'MOQ 5,000', tag: 'OEM' },
    { name: 'CoachVision AI', by: 'MotionIQ SportsTech', stall: 'C-STI-011', cat: 'Cricket', type: 'Software', moq: 'SaaS', tag: 'Live demo' },
    { name: 'ForceTrack Dual Plates', by: 'Velocity Performance Labs', stall: 'C-PSS-006', cat: 'Fitness', type: 'Sports Science', moq: 'Unit', tag: 'Live demo' }
  ];
  const stages = ['Innovation Arena', 'Business Exchange Stage', 'Plenary Hall'];
  const speakers = [
    { id: 's1', name: 'Dr. Meera Raghavan', role: 'Director, High Performance (sample)', org: 'National Sports Science Centre (demo)' },
    { id: 's2', name: 'Lukas Brandt', role: 'Chief Sourcing Officer', org: 'Global Sports Retail GmbH (demo)' },
    { id: 's3', name: 'Arjun Mehta', role: 'Founder & CEO', org: 'MotionIQ SportsTech (demo)' },
    { id: 's4', name: 'Aiko Tanaka', role: 'Head of Venue Technology', org: 'Hayate Sports Engineering (demo)' },
    { id: 's5', name: 'Priya Nair', role: 'Partner', org: 'Kinetic Ventures (demo)' },
    { id: 's6', name: 'Rahul Bhandari', role: 'Managing Director', org: 'Apex Sports India (demo)' },
    { id: 's7', name: 'Sarah Okafor', role: 'Commercial Director', org: 'Stadia Partners UK (demo)' },
    { id: 's8', name: 'Kabir Sethi', role: 'Secretary General', org: 'Sample National Federation' }
  ];
  const sessions = [
    { id: 'x1', day: 1, time: '10:00', end: '11:00', title: 'The Global Sports Economy Meets India', stage: 'Plenary Hall', topic: 'Investment', speakers: ['s5', 's7'], cap: 1200, zone: 'D', status: 'ondemand', dur: '58 min' },
    { id: 'x2', day: 1, time: '11:30', end: '12:15', title: 'Made in India: Scaling Sports Goods Exports', stage: 'Business Exchange Stage', topic: 'Manufacturing', speakers: ['s6', 's2'], cap: 220, zone: 'B', status: 'ondemand', dur: '44 min' },
    { id: 'x3', day: 1, time: '14:00', end: '14:45', title: 'Stadiums as Year-round Assets', stage: 'Innovation Arena', topic: 'Infrastructure', speakers: ['s7', 's4'], cap: 324, zone: 'B', status: 'ondemand', dur: '41 min' },
    { id: 'x4', day: 1, time: '16:00', end: '17:00', title: 'Startup Pitch Round 1: Athlete Tech', stage: 'Innovation Arena', topic: 'Startups', speakers: ['s5'], cap: 324, zone: 'C', status: 'ondemand', dur: '62 min' },
    { id: 'x5', day: 2, time: '10:00', end: '10:45', title: 'The Future of AI Coaching', stage: 'Innovation Arena', topic: 'SportsTech', speakers: ['s3', 's1'], cap: 324, zone: 'C', status: 'live', dur: '45 min' },
    { id: 'x6', day: 2, time: '11:00', end: '11:45', title: 'Sports Science for the Next Olympic Cycle', stage: 'Innovation Arena', topic: 'Sports Science', speakers: ['s1'], cap: 324, zone: 'C', status: 'upcoming', dur: '45 min' },
    { id: 'x7', day: 2, time: '12:00', end: '12:45', title: 'Buyer Briefing: European Football Retail', stage: 'Business Exchange Stage', topic: 'Manufacturing', speakers: ['s2'], cap: 220, zone: 'D', status: 'upcoming', dur: '45 min' },
    { id: 'x8', day: 2, time: '14:00', end: '15:00', title: 'AI in Sport: Broadcast, Fans and Data', stage: 'Plenary Hall', topic: 'SportsTech', speakers: ['s3', 's4'], cap: 1200, zone: 'C', status: 'upcoming', dur: '60 min' },
    { id: 'x9', day: 2, time: '15:30', end: '16:15', title: 'Investing in Indian Sports Startups', stage: 'Business Exchange Stage', topic: 'Investment', speakers: ['s5', 's3'], cap: 220, zone: 'D', status: 'upcoming', dur: '45 min' },
    { id: 'x10', day: 3, time: '10:00', end: '10:45', title: 'Federations & the Grassroots Pipeline', stage: 'Plenary Hall', topic: 'Federations', speakers: ['s8'], cap: 1200, zone: 'A', status: 'upcoming', dur: '45 min' },
    { id: 'x11', day: 3, time: '11:30', end: '12:30', title: 'Startup Pitch Final', stage: 'Innovation Arena', topic: 'Startups', speakers: ['s5', 's3'], cap: 324, zone: 'C', status: 'upcoming', dur: '60 min' },
    { id: 'x12', day: 3, time: '14:00', end: '14:45', title: 'Surfaces, Turf and Climate-ready Venues', stage: 'Innovation Arena', topic: 'Infrastructure', speakers: ['s7'], cap: 324, zone: 'B', status: 'upcoming', dur: '45 min' }
  ];
  const states = [
    { id: 'GJ', name: 'Gujarat', identity: 'Host-city ambitions and integrated sports enclaves', sports: ['Athletics', 'Football', 'Aquatics'], venues: 'Sardar Vallabhbhai Patel Sports Enclave (sample)', pav: 'A-STA-P1', x: 22, y: 50 },
    { id: 'OD', name: 'Odisha', identity: 'Hockey capital and high-performance centres', sports: ['Hockey', 'Athletics', 'Football'], venues: 'Kalinga Stadium (sample)', pav: 'A-STA-P2', x: 64, y: 54 },
    { id: 'HR', name: 'Haryana', identity: 'Wrestling, boxing and Olympic medal heartland', sports: ['Wrestling', 'Boxing', 'Javelin'], venues: 'Tau Devi Lal Stadium (sample)', pav: 'A-STA-P3', x: 36, y: 25 },
    { id: 'MH', name: 'Maharashtra', identity: 'Commercial sport, leagues and manufacturing', sports: ['Cricket', 'Kabaddi', 'Shooting'], venues: 'Balewadi Sports Complex (sample)', pav: 'A-STA-P4', x: 32, y: 60 },
    { id: 'TN', name: 'Tamil Nadu', identity: 'Chess, motorsport and coastal sport', sports: ['Chess', 'Motorsport', 'Squash'], venues: 'Jawaharlal Nehru Stadium, Chennai (sample)', pav: 'A-STA-P4', x: 45, y: 86 },
    { id: 'KA', name: 'Karnataka', identity: 'SportsTech and athlete science ecosystem', sports: ['Badminton', 'Athletics', 'Swimming'], venues: 'Sree Kanteerava Stadium (sample)', pav: 'A-STA-P3', x: 36, y: 77 }
  ];
  const countries = [
    { id: 'JP', name: 'Japan', pav: 'D-CTY-P1', profile: 'Precision timing, materials and venue engineering', companies: 9, lon: 138, lat: 36 },
    { id: 'DE', name: 'Germany', pav: 'D-CTY-P2', profile: 'Retail, lighting, engineering and football industry', companies: 12, lon: 10, lat: 51 },
    { id: 'GB', name: 'United Kingdom', pav: 'D-CTY-P3', profile: 'Venue operations, leagues and sports media', companies: 10, lon: -2, lat: 54 },
    { id: 'AE', name: 'UAE', pav: 'D-CTY-P4', profile: 'Event hosting, investment and sports tourism', companies: 7, lon: 54, lat: 24 },
    { id: 'AU', name: 'Australia', pav: 'D-CTY-P5', profile: 'Sports science, seating and stadium delivery', companies: 8, lon: 134, lat: -25 },
    { id: 'US', name: 'United States', pav: 'D-CTY-P6', profile: 'SportsTech, fan engagement and media rights', companies: 11, lon: -98, lat: 39 }
  ];
  const startups = [
    { name: 'KheloLens', country: 'India', tech: 'Computer vision', sport: 'Kabaddi', problem: 'Manual raid analysis takes coaches hours per match', stage: 'Seed', seeking: ['Investor', 'Partner'], stall: 'C-SUV-004', pitch: 'Day 1 · 16:20' },
    { name: 'RecovR', country: 'India', tech: 'Wearable + app', sport: 'Athletics', problem: 'Athletes lack objective recovery readiness data', stage: 'Pre-Series A', seeking: ['Buyer', 'Investor'], stall: 'C-SUV-011', pitch: 'Day 1 · 16:35' },
    { name: 'Turfsense', country: 'Netherlands', tech: 'IoT sensors', sport: 'Football', problem: 'Pitch wear is detected too late to prevent damage', stage: 'Series A', seeking: ['Buyer', 'Partner'], stall: 'C-SUV-017', pitch: 'Day 3 · 11:40' },
    { name: 'FanLoop', country: 'UAE', tech: 'Gamification', sport: 'Cricket', problem: 'Regional leagues struggle to retain digital fans', stage: 'Seed', seeking: ['Partner'], stall: 'C-SUV-020', pitch: 'Day 3 · 11:55' },
    { name: 'GripAI', country: 'India', tech: 'Edge AI', sport: 'Archery', problem: 'Form faults are invisible without expensive labs', stage: 'Pre-seed', seeking: ['Investor'], stall: 'C-SUV-023', pitch: 'Day 1 · 16:50' },
    { name: 'Paceline', country: 'Australia', tech: 'Data platform', sport: 'Multi-sport', problem: 'Academies cannot compare talent across regions', stage: 'Seed', seeking: ['Buyer', 'Investor'], stall: 'C-SUV-028', pitch: 'Day 3 · 12:10' }
  ];
  const matches = [
    { name: 'Global Sports Retail GmbH', country: 'Germany', role: 'Buyer', seeking: 'Football Equipment', score: 94, why: ['Product fit', 'Market fit', 'Buyer requirement', 'Geographic interest'] },
    { name: 'Northline Distribution Ltd', country: 'United Kingdom', role: 'Distributor', seeking: 'Training Equipment', score: 88, why: ['Product fit', 'Buyer requirement', 'Geographic interest'] },
    { name: 'Gulf Arena Supplies', country: 'UAE', role: 'Buyer', seeking: 'Goal Systems & Nets', score: 81, why: ['Product fit', 'Market fit'] },
    { name: 'Kinetic Ventures', country: 'India', role: 'Investor', seeking: 'Manufacturing scale-up', score: 72, why: ['Market fit', 'Geographic interest'] }
  ];
  window.ISE = { Z, zones: [Z.A, Z.B, Z.C, Z.D], clusters, exhibitors, products, stages, speakers, sessions, states, countries, startups, matches,
    sp: id => speakers.find(s => s.id === id), cl: id => clusters.find(c => c.id === id) };
})();
